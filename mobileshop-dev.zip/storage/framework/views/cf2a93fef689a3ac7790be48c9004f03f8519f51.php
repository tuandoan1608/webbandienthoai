<?php if($parent->categorychildrent->count()): ?>
    <ul>
        <?php $__currentLoopData = $parent->categorychildrent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li><a class="uppercase" href="/pk/<?php echo e($child->slug); ?>"><?php echo e($child->name); ?></a></li>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
<?php endif; ?>
<?php /**PATH C:\Users\tuan\Desktop\mobileshop-dev\mobileshop-dev\resources\views/client//layout/parentmenu.blade.php ENDPATH**/ ?>
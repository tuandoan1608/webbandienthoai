<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
   
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tuan\Desktop\mobileshop-dev\mobileshop-dev\resources\views/admin/home/index.blade.php ENDPATH**/ ?>
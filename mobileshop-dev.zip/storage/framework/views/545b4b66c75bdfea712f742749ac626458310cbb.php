<?php if($menuparent->categorychildrent->count()): ?>
    <ul class="megamenu hb-megamenu">
        <?php $__currentLoopData = $menuparent->categorychildrent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a class="uppercase" style="color: black"><?php echo e($parent->name); ?></a>
                <?php echo $__env->make('client..layout.parentmenu',['parent'=>$parent], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php /**PATH C:\Users\tuan\Desktop\mobileshop-dev\mobileshop-dev\resources\views/client/layout/child.blade.php ENDPATH**/ ?>
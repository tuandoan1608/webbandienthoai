<?php

namespace App\Http\Controllers;

use App\category;
use App\Components\Recusive;
use App\product;
use App\producttype;
use Illuminate\Http\Request;

class accessoriesController extends Controller
{
    
}

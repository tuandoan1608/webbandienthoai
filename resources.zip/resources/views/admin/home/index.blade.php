@extends('admin.master')

@section('content')

    <div class="content-wrapper">
   
    </div>
@endsection
@section('script')
    
@endsection
